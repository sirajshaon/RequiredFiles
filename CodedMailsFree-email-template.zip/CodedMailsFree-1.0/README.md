# Codedmails  - HTML Email templates

![Codedmails Banner](https://codedmails.com/images/banner-codedemails.png)


***This repository contains the ready to use HTML email templates***

**To view each template live, please visit [codedmails]**

## Support
If you find any bug or issue, feel free to open an issue here. 

**_Happy Emailing! :)_**

[codedmails]: https://codedmails.com
